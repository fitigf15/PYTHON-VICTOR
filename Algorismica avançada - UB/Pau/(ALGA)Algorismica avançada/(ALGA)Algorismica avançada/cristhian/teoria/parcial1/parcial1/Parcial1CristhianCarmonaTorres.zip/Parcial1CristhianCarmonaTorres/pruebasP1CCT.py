# Cristhian Carmona torres
# Pruebas:
# Fichero con grafo euleriano: ge.txt
grafo = llegir_graf()
print "0: Grafo NO Eureliano | 1: Grafo Eureliano >>> \n", iniDFS(grafo)
