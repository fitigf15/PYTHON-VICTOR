def main():
    print "Aquest programa suma, resta i multiplica un nombre"
    x = input("Escriu el nombre")
    print x
    b = x + 3
    print b
    c = b * 2
    print c
    d = c - 4
    print d
    e = a - 2 * d
    print e
    f = e + 3
    print f
main()